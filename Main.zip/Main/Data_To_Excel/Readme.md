Offsets used are
alpha, beta, gamma, alpha_offset
0.14, -0.31, -0.31, 66.26